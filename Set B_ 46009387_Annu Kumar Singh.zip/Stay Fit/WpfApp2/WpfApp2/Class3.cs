﻿namespace WpfApp2
{
    internal class Class3
    {
    }
}