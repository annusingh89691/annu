﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp2.MainWindow.xaml;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        private void btnRegister_Click(object sender, RoutedEventArgs e)
        {
            Registeremployee();
        }

        private void btnReset_Click(object sender, RoutedEventArgs e)
        {
            Reset();
        }

        private void Registeremployee() //add employee method

        {

            try

            {

                int empid;

                string empname;

                string gender;

                string location;

                string contact;

                string bgroup;

                string coverage;



                //

                bool employeeRegister;

                //

                empid = Convert.ToInt32(txtempid.Text);

                empname = txtempname.Text;



                if (radmale.IsChecked == true) // check radiobutton

                {

                    gender = radmale.Content.ToString();

                }

                else

                {

                    gender = radfemale.Content.ToString();

                }

                location = cmblocation.Text;

                contact = txtcontact_no.Text;

                bgroup = cmbblood_group.Text;

                coverage = cmbcoverage.Text;



                //

                Class3 objemployee = new Class3(); //assigning values to object

                {

                    objemployee.empid = empid;

                    objemployee.empname = empname;

                    objemployee.gender = gender;

                    objemployee.location = location;

                    // objemployee.contact_no = txtcontact_no;

                    //objemployee.blood_group = cmbblood_group;

                    //objemployee.coverage = coverage;

                };

                employeeRegister = Class1.RegisterBL(objemployee);

                if (employeeRegister == true) //checking employeeaddedflag

                {

                    MessageBox.Show("Thank You!!! Details successfully registered.");

                }

                else

                {

                    MessageBox.Show("Sorry!!! Unregistered.");

                }

            }

            catch (Exception ex)

            {

                MessageBox.Show(ex.Message);

            }

        }



        private void Reset() //clear method

        {

            txtempid.Clear();

            txtempname.Clear();

            cmblocation.SelectedIndex = -1;

            txtcontact_no.Clear();

            cmbblood_group.SelectedIndex = -1;

            cmbcoverage.SelectedValue = -1;

            radmale.IsChecked = false;

            radfemale.IsChecked = false;

        }





    }
}
}
namespace WpfApp2.MainWindow.xaml
{
    class txtempid
    {
    }
}