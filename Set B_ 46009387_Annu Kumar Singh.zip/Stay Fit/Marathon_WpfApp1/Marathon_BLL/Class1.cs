﻿using Marathon_DAL;
using Marathon_Entities;
using Marathon_Exception;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marathon_BLL
{
    public class Class1
    {

        private static bool ValidateEmployee(Class3 obj1)
        {
            StringBuilder sb = new StringBuilder();
            bool validEmployee = true;
            try
            {
                if (obj1.empid <= 0)
                {

                    validEmployee = false;
                    sb.Append(Environment.NewLine
                        + "Employee Id should be of exactly 6 digits.");
                }
                if (obj1.empname == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Employee Name should have only alphabets.");
                }

                if (obj1.gender == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Gender can be either M or F .");
                }

                if (obj1.location == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Location can be Chennai, Bangalore, Hyderabad, Pune, Mumbai.");
                }
                if (Convert.ToInt32(obj1.contact_no) > 100 || Convert.ToInt32(obj1.contact_no) <= 0)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Contact number shoild be a proper mobile number.");
                }

                if (obj1.blood_group == string.Empty)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Blood group can be O+ve, O-ve, A+ve, B+ve, A-ve, b-ve, AB+ve.");
                }

                if (Convert.ToInt32(obj1.coverage) < 1)
                {
                    validEmployee = false;
                    sb.Append(Environment.NewLine + "Coverage should be 5km or 10km");
                }
                if (validEmployee == false)
                {
                    throw new Exceptions1(sb.ToString());
                }
            }
            catch (Exceptions1 e)
            {
                throw e;
            }
            return validEmployee;


        }


        public static bool RegisterBL(Class3 obj1)
        {
            bool employeeRegister = false;
            try
            {
                if (ValidateEmployee(obj1))
                {
                    Class2 dal = new Class2();
                    employeeRegister = dal.RegisterDL(obj1);
                    return employeeRegister;
                }
            }
            catch (Exceptions1 ex)
            {
                throw ex;
            }

            return employeeRegister;
        }

        public static bool RegisterBL(Class1 objemployee)
        {
            throw new NotImplementedException();
        }

        public static bool ResetBL(Class3 obj1)
        {
            bool employeeReset = false;
            try
            {
                if (ValidateEmployee(obj1))
                {
                    Class2 dal = new Class2();
                    employeeReset = dal.ResetDL(obj1);
                    return employeeReset;
                }
            }
            catch (Exceptions1 ex)
            {
                throw ex;
            }

            return employeeReset;
        }
    }
}
