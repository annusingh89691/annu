﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Threading.Tasks;

namespace Marathon_Exception
{
    
        public class Exceptions1 : Exception
        {
            public Exceptions1()
            {
            }

            public Exceptions1(string message) : base(message)
            {
            }

            public Exceptions1(string message, Exception innerException) : base(message, innerException)
            {
            }

            protected Exceptions1(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }
    
}
