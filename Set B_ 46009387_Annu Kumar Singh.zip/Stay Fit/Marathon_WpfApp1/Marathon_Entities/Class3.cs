﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Marathon_Entities
{
    public class Class3
    {

        public int empid { get; set; }
        public string empname { get; set; }
        public string gender { get; set; }
        public string location { get; set; }
        public int contact_no { get; set; }
        public string blood_group { get; set; }
        public int coverage { get; set; }

        public Class3()
        {

        }


    }
}
