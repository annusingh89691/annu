﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Data.SqlClient;
using Marathon_Entities;
using System.Runtime.Serialization;

namespace Marathon_DAL
{
    public class Class2
    {

        public bool RegisterDL(Class3 obj1)
        {
            bool employeeRegister = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["MarathonConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009387].Register_Details", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_empid = new SqlParameter("@id", obj1.empid);
                SqlParameter objSqlParam_empname = new SqlParameter("@Name", obj1.empname);
                SqlParameter objSqlParam_gender = new SqlParameter("@Gender", obj1.gender);
                SqlParameter objSqlParam_location = new SqlParameter("@Location", obj1.location);
                SqlParameter objSqlParam_contact_no = new SqlParameter("@Contact_no", obj1.contact_no);
                SqlParameter objSqlParam_blood_group = new SqlParameter("@Blood Group", obj1.blood_group);
                SqlParameter objSqlParam_coverage = new SqlParameter("@Coverage", obj1.coverage);
                //
                objCom.Parameters.Add(objSqlParam_empid);
                objCom.Parameters.Add(objSqlParam_empname);
                objCom.Parameters.Add(objSqlParam_gender);
                objCom.Parameters.Add(objSqlParam_location);
                objCom.Parameters.Add(objSqlParam_contact_no);
                objCom.Parameters.Add(objSqlParam_blood_group);
                objCom.Parameters.Add(objSqlParam_coverage);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeRegister = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Exceptions1(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeRegister;
        }

        internal class Exceptions1 : Exception
        {
            public Exceptions1()
            {
            }

            public Exceptions1(string message) : base(message)
            {
            }

            public Exceptions1(string message, Exception innerException) : base(message, innerException)
            {
            }

            protected Exceptions1(SerializationInfo info, StreamingContext context) : base(info, context)
            {
            }
        }



        public bool ResetDL(Class3 obj1)
        {
            bool employeeReset = false;
            SqlConnection objCon = null;
            try
            {
                objCon = new SqlConnection(
                ConfigurationManager.ConnectionStrings["MarathonConnectionString"].ConnectionString);
                SqlCommand objCom = new SqlCommand("[46009387].Register_Details", objCon);
                objCom.CommandType = CommandType.StoredProcedure;
                //
                SqlParameter objSqlParam_empid = new SqlParameter("@id", obj1.empid);
                SqlParameter objSqlParam_empname = new SqlParameter("@Name", obj1.empname);
                SqlParameter objSqlParam_gender = new SqlParameter("@Gender", obj1.gender);
                SqlParameter objSqlParam_location = new SqlParameter("@Location", obj1.location);
                SqlParameter objSqlParam_contact_no = new SqlParameter("@Contact_no", obj1.contact_no);
                SqlParameter objSqlParam_blood_group = new SqlParameter("@Blood Group", obj1.blood_group);
                SqlParameter objSqlParam_coverage = new SqlParameter("@Coverage", obj1.coverage);
                //
                objCom.Parameters.Add(objSqlParam_empid);
                objCom.Parameters.Add(objSqlParam_empname);
                objCom.Parameters.Add(objSqlParam_gender);
                objCom.Parameters.Add(objSqlParam_location);
                objCom.Parameters.Add(objSqlParam_contact_no);
                objCom.Parameters.Add(objSqlParam_blood_group);
                objCom.Parameters.Add(objSqlParam_coverage);
                //
                objCon.Open();
                objCom.ExecuteNonQuery();
                employeeReset = true;
            }
            catch (SqlException objSqlEx)
            {
                throw new Exceptions1(objSqlEx.Message);
            }
            finally
            {
                objCon.Close();
            }
            return employeeReset;
        }





    }

    
}
