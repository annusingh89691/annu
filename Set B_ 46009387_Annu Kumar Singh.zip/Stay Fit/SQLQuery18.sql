use Training_19Sep19_Pune
go

create table [46009387].[Marathon]
(

empid int NOT NULL,
CONSTRAINT empid UNIQUE(empid),
empname varchar(20),
gender varchar(10),
location varchar(100),
contact_no int,
blood_group varchar(10),
coverage int
);

drop table [46009387].[Marathon]


Create PROCEDURE [46009387].Register    
@empid int,
@empname varchar(50),
@gender varchar(10),
@location varchar(100),
@contact_no int,
@blood_group varchar(10),
@coverage int

AS
BEGIN
	insert into [46009387].class values(@empid, @empname, @gender,@location, @contact_no, @blood_group, @coverage)
END

GO
 