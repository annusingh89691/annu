﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ERF_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the interface name "IService1" in both code and config file together.
    [ServiceContract]
    public interface IElectorServices
    {
        [OperationContract]
        bool AddElector(Elector elector);

        // TODO: Add your service operations here
    }

    [DataContract]
    public class Elector
    {
        [DataMember]
        public int ElectorId{ get; set; }
        [DataMember]
        public string ElectorName { get; set; }
        [DataMember]
        public DateTime ElectorDateofBirth { get; set; }
        [DataMember]
        public string ElectorGender { get; set; }
        [DataMember]
        public string ElectorMobileNo { get; set; }
        [DataMember]
        public string ElectorAddress { get; set; }
        [DataMember]
        public string ElectorAddressProof { get; set; }
        [DataMember]
        public string ElectorAgeProof { get; set; }
        [DataMember]
        public string ElectorEmailAddress { get; set; }
    }

    
    
}
