﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;
using System.Configuration;
using System.Data.SqlClient;


namespace ERF_Service
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class ElectorSerives : IElectorServices
    {
        SqlConnection sqlConnection = null;
        SqlCommand sqlCommand = null;
        public bool AddElector(Elector elector)
        {
            int electoralAdded = 0;
            sqlConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ERF_Service"].ConnectionString);
            try
            {
                sqlCommand = new SqlCommand("[46008556].Register8556", sqlConnection);
                sqlCommand.CommandType = System.Data.CommandType.StoredProcedure;
                sqlCommand.Parameters.AddWithValue("@electorName", elector.ElectorName);
                sqlCommand.Parameters.AddWithValue("@electorGender", elector.ElectorGender);
                sqlCommand.Parameters.AddWithValue("@electorDOB", elector.ElectorDateofBirth);
                sqlCommand.Parameters.AddWithValue("@electorMobileNo", elector.ElectorMobileNo);
                sqlCommand.Parameters.AddWithValue("@electorEmailAddress", elector.ElectorEmailAddress);
                sqlCommand.Parameters.AddWithValue("@electorAddress", elector.ElectorAddress);
                sqlCommand.Parameters.AddWithValue("@electorAgeProof", elector.ElectorAgeProof);
                sqlCommand.Parameters.AddWithValue("@electorAddressProof", elector.ElectorAddressProof);

                sqlConnection.Open();

                electoralAdded=sqlCommand.ExecuteNonQuery();
            }
            catch(SqlException sqlEx)
            {
                throw sqlEx;
            }
            catch(Exception ex)
            {
                throw ex;
            }
            finally
            {
                sqlConnection.Close();
            }
            if(electoralAdded>0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }
    }
}
